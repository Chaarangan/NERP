## Background
`NERP` is developed as a part of [National NLP Clinical Challenges (n2c2)](https://n2c2.dbmi.hms.harvard.edu/2022-track-1)’s submission as a pipeline for training NER models.